const mongoose = require('mongoose');

const ProjectSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  student: { type: String, required: true },
  year: { type: String, required: true },
  tags: [String],
  video: { type: String },
  files: [{ type: String }],  // You can store file paths/URLs here
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  comments: [
    {
      user: { type: String, required: true },
      text: { type: String, required: true },
      createdAt: { type: Date, default: Date.now },
    },
  ],
});

module.exports = mongoose.model('Project', ProjectSchema);
