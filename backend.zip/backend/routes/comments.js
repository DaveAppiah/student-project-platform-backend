const express = require('express');
const Project = require('Project');
const router = express.Router();

// Add Comment to Project
router.post('/:projectId', async (req, res) => {
  const { projectId } = req.params;
  const { user, text } = req.body;
  try {
    const project = await Project.findById(projectId);
    project.comments.push({ user, text });
    await project.save();
    res.status(201).json(project);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;


