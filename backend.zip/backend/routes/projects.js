const express = require('express');
const Project = require('Project');
const router = express.Router();
const protectAdmin = require('../middleware/protectAdmin');

// Submit Project (only for logged-in students)
router.post('/', async (req, res) => {
  const { title, description, student, year, tags, video, files } = req.body;
  try {
    const newProject = new Project({ title, description, student, year, tags, video, files });
    await newProject.save();
    res.status(201).json(newProject);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get All Approved Projects (for browsing)
router.get('/', async (req, res) => {
  const projects = await Project.find({ status: 'approved' });
  res.json(projects);
});

// Admin Approve/Reject Project
router.patch('/:id/status', async (req, res) => {
  const { status } = req.body;
  const project = await Project.findByIdAndUpdate(req.params.id, { status }, { new: true });
  res.json(project);
});

router.patch('/:id/status', protectAdmin, async (req, res) => {
  const { status } = req.body;
  const project = await Project.findByIdAndUpdate(req.params.id, { status }, { new: true });
  res.json({ message: 'Status updated successfully' });
});

module.exports = router;
